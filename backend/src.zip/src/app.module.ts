import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { typeOrmConfig } from './config/typeorm.config';
import { ProductosModule } from './modules/productos/productos.module';
import { ClienteModule } from './modules/cliente/cliente.module';
import { MaterialModule } from './modules/material/material.module';
import { VentaModule } from './modules/venta/venta.module';
import { CategoriaModule } from './modules/categoria/categoria.module';
import { UsuarioModule } from './modules/usuario/usuario.module';
import { AuthModule } from './auth/auth.module';
import { PagoModule } from './modules/pago/pago.module';
import { SaleDetailsModule } from './modules/sale_details/sale_details.module';

@Module({
  imports: [ConfigModule.forRoot({isGlobal : true}),
  TypeOrmModule.forRoot(typeOrmConfig),
  ProductosModule,
  ClienteModule,
  MaterialModule,
  VentaModule,
  CategoriaModule,
  UsuarioModule,
  PagoModule,
  AuthModule, 
  SaleDetailsModule,
],
  controllers: [],
  providers: [],
  
})
export class AppModule {}
